<template>
  <page-header-wrapper>
    <a-card :body-style="{ padding: '24px 32px' , height:'650px'}" :bordered="false">
    </a-card>
    <div style="width:900px;height: 200px;">
      <a-card hoverable style="width:200px">
        <img
          slot="cover"
          alt="example"
          src="~@/assets/jdlogo.jpg"
        />
        <a-card-meta title="自营与非自营的的比例">
          <template slot="description">
            www.jd.com
          </template>
        </a-card-meta>
      </a-card>
      <a-card hoverable style="width:200px;top: -266px;left: 250px;">
        <img
          slot="cover"
          alt="example"
          src="~@/assets/jdlogo.jpg"
        />
        <a-card-meta title="刷新率前五">
          <template slot="description">
            www.jd.com
          </template>
        </a-card-meta>
      </a-card>
      <a-card hoverable style="width:200px;top: -534px;left: 490px;">
        <img
          slot="cover"
          alt="example"
          src="~@/assets/jdlogo.jpg"
        />
        <a-card-meta title="上市时间后十">
          <template slot="description">
            www.jd.com
          </template>
        </a-card-meta>
      </a-card>
      <a-card hoverable style="width:200px;top: -801px;left: 730px;">
        <img
          slot="cover"
          alt="example"
          src="~@/assets/jdlogo.jpg"
        />
        <a-card-meta title="自营与非自营的的比例">
          <template slot="description">
            www.jd.com
          </template>
        </a-card-meta>
      </a-card>
      <a-card hoverable style="width:200px;top: -1066px;left: 980px;">
        <img
          slot="cover"
          alt="example"
          src="~@/assets/jdlogo.jpg"
        />
        <a-card-meta title="自营与非自营的的比例">
          <template slot="description">
            www.jd.com
          </template>
        </a-card-meta>
      </a-card>
    </div>
  </page-header-wrapper>
</template>
