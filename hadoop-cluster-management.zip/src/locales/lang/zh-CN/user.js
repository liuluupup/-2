export default {
  'user.login.userName': '用户名',
  'user.login.password': '密码',
  'user.login.username.placeholder': '请输入用户名',
  'user.login.password.placeholder': '请输入用密码',
  'user.login.message-invalid-credentials': '账户或密码错误',
  'user.login.remember-me': '自动登录',
  'user.login.login': '登录',
  'user.userName.required': '请输入帐户名或邮箱地址',
  'user.password.required': '请输入密码！'
}
