/* eslint-disable */
export const printANSI = () => {
  let text = `四川凌浠科技有限公司`
  console.log(`%c${text}`, 'color: #fc4d50')
  }
